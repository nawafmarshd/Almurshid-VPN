# تطبيق اتصالات المرشد (Al-Murshid Telecom) — VPN

تطبيق أندرويد (Kotlin + Jetpack Compose) بيستخدم بروتوكول WireGuard عبر مكتبة WireGuard الرسمية.
بيدعم سيرفرات WireGuard عادية وإعدادات Cloudflare WARP.

## هيكل المشروع

```
AlMurshidTelecom/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── remote-config/servers.json          ← الملف اللي بترفعه على GitHub
└── app/
    ├── build.gradle.kts                ← هون بتعدّل رابط الإعدادات ورقم الواتساب
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/servers.json         ← نسخة احتياطية مدمجة بالتطبيق
        ├── res/                        ← الشعار والألوان
        └── java/com/almurshid/telecom/
            ├── MainActivity.kt         ← نقطة الدخول + إذن الإشعارات
            ├── MainViewModel.kt
            ├── ui/MainScreen.kt        ← الواجهة (زر الاتصال، الإحصائيات، أزرار الدعم)
            ├── ui/Theme.kt             ← الوضع الداكن
            ├── vpn/VpnManager.kt       ← تشغيل/إيقاف النفق + إحصائيات السرعة
            ├── vpn/VpnForegroundService.kt ← الإشعار الدائم
            ├── vpn/WgConfigFactory.kt  ← تحويل بيانات السيرفر لإعداد WireGuard
            └── data/RemoteConfigRepository.kt ← جلب الإعدادات من الرابط الخارجي
```

## خطوات البناء وتوليد ملف APK

1. نزّل وثبّت **Android Studio** (أحدث إصدار) من developer.android.com/studio.
2. فك ضغط المشروع، وافتح Android Studio واختار **File ← Open** وحدد مجلد `AlMurshidTelecom`.
3. استنى **Gradle Sync** يخلص (أول مرة بدو إنترنت ويحمّل المكتبات، ممكن ياخد كم دقيقة).
4. افتح `app/build.gradle.kts` وعدّل سطرين:
   - `REMOTE_CONFIG_URL` ← رابط Raw لملف `servers.json` على GitHub.
   - `SUPPORT_WHATSAPP` ← رقم واتساب المحل بالصيغة الدولية بدون `+` (مثال `963912345678`).
5. جهّز ملف السيرفرات: عدّل `remote-config/servers.json` ببيانات سيرفراتك، وارفعه على مستودع GitHub، وخذ رابط **Raw**.
   (بتقدر تغيّره بعدين بدون ما تعيد بناء التطبيق.)
6. للتجربة: وصّل موبايلك بكبل، فعّل **USB debugging**، واضغط **Run ▶**.
7. لتوليد ملف التثبيت: من القائمة **Build ← Build Bundle(s) / APK(s) ← Build APK(s)**.
   بيظهر إشعار "APK(s) generated" ← اضغط **locate**، الملف بيكون:
   `app/build/outputs/apk/debug/app-debug.apk`
8. للنسخة النهائية الأخف: **Build ← Select Build Variant** وغيّر `app` لـ **release**، ثم Build APK.
   الملف: `app/build/outputs/apk/release/app-release.apk`
   (موقّع بمفتاح debug لتسهيل التثبيت؛ للنشر على Google Play لازم مفتاح توقيع خاص.)
9. انسخ الـ APK للموبايل وثبّته (لازم تفعّل **السماح بالتثبيت من مصادر غير معروفة**).

### البناء من سطر الأوامر (اختياري)
```
gradle wrapper --gradle-version 8.9      # مرة وحدة فقط لتوليد gradlew
./gradlew assembleRelease
```
(يلزم JDK 17 و Android SDK.)

## تنسيق ملف servers.json

```json
{
  "version": 1,
  "announcement": "رسالة تظهر أعلى التطبيق (اتركها فاضية لإخفائها)",
  "contacts": { "whatsapp": "963912345678", "phone": "", "telegram": "", "facebook": "" },
  "servers": [
    {
      "id": "server-1",
      "name": "اسم يظهر للمستخدم",
      "enabled": true,
      "privateKey": "...", "address": "10.8.0.2/32", "dns": "1.1.1.1",
      "publicKey": "...", "endpoint": "IP:51820",
      "allowedIps": "0.0.0.0/0, ::/0", "keepalive": 25
    },
    {
      "id": "warp-1",
      "name": "Cloudflare WARP",
      "wgConfig": "نص ملف wg-quick كامل بسطر \\n بين الأسطر"
    }
  ]
}
```

- لتعطيل سيرفر مؤقتاً: `"enabled": false`.
- `wgConfig` بتحط فيه محتوى ملف الإعداد كامل (مثلاً الناتج من أداة `wgcf` لـ WARP).
- يفضّل استخدام عنوان IP مباشر بـ `endpoint` بدل اسم نطاق.
- GitHub Raw بيخزّن الملف مؤقتاً حوالي 5 دقايق، فالتحديث مش لحظي.

## تنبيه أمني مهم

ملف `servers.json` على GitHub العام **ظاهر لأي شخص** بيعرف الرابط، وفيه المفاتيح الخاصة للـ WireGuard.
أي حدا بيستخرج الملف بقدر يستخدم سيرفرك. لذلك:
- استخدم مستودع Private مع رابط وصول، أو استضيف الملف على سيرفرك مع حماية.
- أو خلّي كل سيرفر محدود السرعة/المستخدمين من جهة السيرفر.

## ملاحظات

- المشروع لسا ما انبنى هون (ما في Android SDK ولا إنترنت بالبيئة)، فالمرة الأولى ممكن تطلع ملاحظات بسيطة بالـ Sync بتنحل بسرعة.
- الدعم الحالي لبروتوكول WireGuard فقط. VLESS وShadowsocks بدّن محرك إضافي (مثل sing-box أو xray) وبيكبّر حجم التطبيق كتير.
- إعداد "Always-on VPN" من إعدادات النظام غير مدعوم بهالإصدار.
