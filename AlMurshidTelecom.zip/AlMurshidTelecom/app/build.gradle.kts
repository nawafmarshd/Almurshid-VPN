plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.almurshid.telecom"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.almurshid.telecom"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // ===== عدّل هالقيمتين قبل البناء =====
        // رابط ملف servers.json (GitHub Raw)
        buildConfigField(
            "String",
            "REMOTE_CONFIG_URL",
            "\"https://raw.githubusercontent.com/YOUR_USER/YOUR_REPO/main/servers.json\""
        )
        // رقم واتساب الدعم الفني بالصيغة الدولية بدون + وبدون أصفار (مثال: 963912345678)
        buildConfigField("String", "SUPPORT_WHATSAPP", "\"963900000000\"")

        // تقليل حجم الـ APK: معالجات الموبايل فقط (ARM)
        // إذا بدك تجرب على محاكي x86 ضيف "x86_64" هون
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // توقيع بمفتاح debug حتى ينبني APK جاهز للتثبيت بدون ما تعمل keystore.
            // للنشر على متجر Play لازم تعمل مفتاح توقيع خاص فيك.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    // مكتبة WireGuard الرسمية (فيها VpnService + المحرك الأصلي wireguard-go)
    implementation("com.wireguard.android:tunnel:1.0.20230706")
}
