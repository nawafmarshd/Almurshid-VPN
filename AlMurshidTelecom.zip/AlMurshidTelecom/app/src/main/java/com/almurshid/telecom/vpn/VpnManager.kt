package com.almurshid.telecom.vpn

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.almurshid.telecom.data.VpnServer
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class ConnState { Disconnected, Connecting, Connected, Disconnecting, Error }

data class VpnStatus(
    val state: ConnState = ConnState.Disconnected,
    val serverName: String? = null,
    val error: String? = null,
    val rxBytes: Long = 0,
    val txBytes: Long = 0,
    val rxSpeed: Long = 0,
    val txSpeed: Long = 0,
    val seconds: Long = 0
)

/**
 * مدير الاتصال: بيشغّل/بيطفي نفق WireGuard عبر GoBackend
 * (اللي بدوره بيستخدم android.net.VpnService لإنشاء واجهة TUN).
 */
object VpnManager {

    private lateinit var appContext: Context
    private val backend: GoBackend by lazy { GoBackend(appContext) }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var statsJob: Job? = null

    private val _status = MutableStateFlow(VpnStatus())
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val tunnel = object : Tunnel {
        override fun getName(): String = "murshid"

        override fun onStateChange(newState: Tunnel.State) {
            // لو النظام أو تطبيق VPN تاني قطع النفق من برّا
            if (newState == Tunnel.State.DOWN && _status.value.state == ConnState.Connected) {
                statsJob?.cancel()
                _status.value = VpnStatus()
            }
        }
    }

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun connect(server: VpnServer) {
        val s = _status.value.state
        if (s == ConnState.Connecting || s == ConnState.Connected || s == ConnState.Disconnecting) return

        _status.value = VpnStatus(state = ConnState.Connecting, serverName = server.name)
        startNotificationService()

        scope.launch {
            mutex.withLock {
                try {
                    val config = WgConfigFactory.build(server)
                    backend.setState(tunnel, Tunnel.State.UP, config)
                    _status.value = VpnStatus(state = ConnState.Connected, serverName = server.name)
                    startStats()
                } catch (e: Exception) {
                    _status.value = VpnStatus(
                        state = ConnState.Error,
                        serverName = server.name,
                        error = friendlyError(e)
                    )
                }
            }
        }
    }

    fun disconnect() {
        scope.launch {
            mutex.withLock {
                _status.update { it.copy(state = ConnState.Disconnecting) }
                statsJob?.cancel()
                try {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                } catch (_: Exception) {
                }
                _status.value = VpnStatus()
            }
        }
    }

    private fun startStats() {
        statsJob?.cancel()
        statsJob = scope.launch {
            val start = SystemClock.elapsedRealtime()
            var lastRx = 0L
            var lastTx = 0L
            while (isActive) {
                delay(1000)
                val stats = try {
                    backend.getStatistics(tunnel)
                } catch (_: Exception) {
                    null
                }
                val rx = stats?.totalRx() ?: 0L
                val tx = stats?.totalTx() ?: 0L
                val seconds = (SystemClock.elapsedRealtime() - start) / 1000
                _status.update {
                    if (it.state != ConnState.Connected) it
                    else it.copy(
                        rxBytes = rx,
                        txBytes = tx,
                        rxSpeed = (rx - lastRx).coerceAtLeast(0),
                        txSpeed = (tx - lastTx).coerceAtLeast(0),
                        seconds = seconds
                    )
                }
                lastRx = rx
                lastTx = tx
            }
        }
    }

    private fun startNotificationService() {
        try {
            ContextCompat.startForegroundService(
                appContext,
                Intent(appContext, VpnForegroundService::class.java)
            )
        } catch (_: Exception) {
            // الاتصال بيشتغل حتى لو ما ظهر الإشعار
        }
    }

    private fun friendlyError(e: Exception): String = when (e) {
        is BadConfigException -> "إعدادات السيرفر غير صحيحة، تأكد من المفاتيح والعنوان"
        else -> e.message?.take(120) ?: "تعذّر إنشاء الاتصال"
    }
}
