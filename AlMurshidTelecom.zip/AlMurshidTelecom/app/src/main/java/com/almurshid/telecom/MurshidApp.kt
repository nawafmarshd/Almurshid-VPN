package com.almurshid.telecom

import android.app.Application
import com.almurshid.telecom.vpn.VpnManager

class MurshidApp : Application() {
    override fun onCreate() {
        super.onCreate()
        VpnManager.init(this)
    }
}
