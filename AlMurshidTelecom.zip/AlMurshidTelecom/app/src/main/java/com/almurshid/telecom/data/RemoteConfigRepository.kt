package com.almurshid.telecom.data

import android.content.Context
import com.almurshid.telecom.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * جلب الإعدادات عن بُعد.
 * الترتيب: الإنترنت (GitHub Raw) ثم آخر نسخة محفوظة ثم النسخة المدمجة داخل التطبيق.
 * هيك التطبيق بيضل شغّال حتى لو الرابط وقع أو ما في نت.
 */
class RemoteConfigRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("remote_config", Context.MODE_PRIVATE)

    suspend fun load(): LoadedConfig = withContext(Dispatchers.IO) {
        val url = BuildConfig.REMOTE_CONFIG_URL

        // 1) من الإنترنت
        if (url.startsWith("https://") && !url.contains("YOUR_USER")) {
            try {
                val json = download(url)
                val cfg = parse(json)
                if (cfg.servers.isNotEmpty()) {
                    prefs.edit().putString(KEY_CACHE, json).apply()
                    return@withContext LoadedConfig(cfg, ConfigSource.Remote)
                }
            } catch (_: Exception) {
                // نكمل على النسخة المحفوظة
            }
        }

        // 2) آخر نسخة ناجحة محفوظة
        val cached = prefs.getString(KEY_CACHE, null)
        if (cached != null) {
            try {
                return@withContext LoadedConfig(parse(cached), ConfigSource.Cache)
            } catch (_: Exception) {
            }
        }

        // 3) النسخة المدمجة بالتطبيق
        val bundled = context.assets.open("servers.json").bufferedReader().use { it.readText() }
        LoadedConfig(parse(bundled), ConfigSource.Bundled)
    }

    private fun download(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"
            conn.useCaches = false
            conn.setRequestProperty("Cache-Control", "no-cache")
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP ${conn.responseCode}")
            }
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    fun parse(json: String): AppConfig {
        val root = JSONObject(json)

        val c = root.optJSONObject("contacts")
        val contacts = Contacts(
            whatsapp = c?.optString("whatsapp", "").orEmpty().trim(),
            phone = c?.optString("phone", "").orEmpty().trim(),
            telegram = c?.optString("telegram", "").orEmpty().trim(),
            facebook = c?.optString("facebook", "").orEmpty().trim()
        )

        val arr = root.getJSONArray("servers")
        val servers = ArrayList<VpnServer>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!o.optBoolean("enabled", true)) continue

            val wg = o.optString("wgConfig", "").trim()
            val server = VpnServer(
                id = o.optString("id", "server-$i"),
                name = o.optString("name", "سيرفر ${i + 1}"),
                wgConfig = wg.ifEmpty { null },
                privateKey = o.optString("privateKey", "").trim(),
                address = o.optString("address", "").trim(),
                dns = o.optString("dns", "1.1.1.1").trim(),
                mtu = if (o.has("mtu")) o.optInt("mtu") else null,
                publicKey = o.optString("publicKey", "").trim(),
                presharedKey = o.optString("presharedKey", "").trim(),
                endpoint = o.optString("endpoint", "").trim(),
                allowedIps = o.optString("allowedIps", "0.0.0.0/0, ::/0").trim(),
                keepalive = o.optInt("keepalive", 25)
            )

            val valid = server.wgConfig != null ||
                (server.privateKey.isNotEmpty() && server.publicKey.isNotEmpty() &&
                    server.endpoint.isNotEmpty() && server.address.isNotEmpty())
            if (valid) servers.add(server)
        }

        return AppConfig(
            version = root.optInt("version", 1),
            announcement = root.optString("announcement", "").trim(),
            contacts = contacts,
            servers = servers
        )
    }

    private companion object {
        const val KEY_CACHE = "cached_json"
    }
}
