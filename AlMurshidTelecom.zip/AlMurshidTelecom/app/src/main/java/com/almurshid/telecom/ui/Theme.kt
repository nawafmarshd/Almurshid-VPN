package com.almurshid.telecom.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B1220)
val Surface1 = Color(0xFF121B2E)
val Surface2 = Color(0xFF1A2640)
val Teal = Color(0xFF19E3B1)
val Green = Color(0xFF2ED573)
val Amber = Color(0xFFFFB02E)
val Red = Color(0xFFFF5C6C)
val Gray = Color(0xFF6B7A99)
val TextMain = Color(0xFFEAF0FF)
val TextDim = Color(0xFF9AA8C7)

private val Scheme = darkColorScheme(
    primary = Teal,
    onPrimary = Bg,
    background = Bg,
    onBackground = TextMain,
    surface = Surface1,
    onSurface = TextMain,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextDim,
    error = Red
)

/** الوضع الداكن هو الافتراضي والوحيد. */
@Composable
fun MurshidTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
