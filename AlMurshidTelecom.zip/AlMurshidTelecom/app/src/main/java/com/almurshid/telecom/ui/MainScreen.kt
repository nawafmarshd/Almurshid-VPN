package com.almurshid.telecom.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.almurshid.telecom.BuildConfig
import com.almurshid.telecom.MainViewModel
import com.almurshid.telecom.R
import com.almurshid.telecom.data.ConfigSource
import com.almurshid.telecom.data.VpnServer
import com.almurshid.telecom.vpn.ConnState
import java.util.Locale

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val status by vm.vpn.collectAsStateWithLifecycle()
    val config by vm.config.collectAsStateWithLifecycle()
    val selected by vm.selectedServer.collectAsStateWithLifecycle()
    val source by vm.source.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()

    // نافذة موافقة النظام على VPN (بتظهر أول مرة بس)
    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) vm.connect()
    }

    fun onToggle() {
        when (status.state) {
            ConnState.Connected, ConnState.Connecting -> vm.disconnect()
            ConnState.Disconnecting -> Unit
            else -> {
                if (selected == null) return
                val intent = VpnService.prepare(context)
                if (intent != null) vpnLauncher.launch(intent) else vm.connect()
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Header()

            val announcement = config?.announcement.orEmpty()
            if (announcement.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Surface2),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        announcement,
                        modifier = Modifier.padding(14.dp),
                        color = Amber,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            ConnectButton(state = status.state, onClick = { onToggle() })
            Spacer(Modifier.height(8.dp))
            StatusText(status.state, status.seconds, status.error)

            Spacer(Modifier.height(20.dp))
            ServerPicker(
                servers = config?.servers.orEmpty(),
                selected = selected,
                enabled = status.state == ConnState.Disconnected || status.state == ConnState.Error,
                onSelect = { vm.select(it) }
            )

            Spacer(Modifier.height(14.dp))
            StatsCard(
                serverName = status.serverName ?: selected?.name,
                connected = status.state == ConnState.Connected,
                rxSpeed = status.rxSpeed,
                txSpeed = status.txSpeed,
                rxBytes = status.rxBytes,
                txBytes = status.txBytes
            )

            Spacer(Modifier.height(14.dp))
            val contacts = config?.contacts
            ContactRow(
                whatsapp = contacts?.whatsapp?.ifEmpty { null } ?: BuildConfig.SUPPORT_WHATSAPP,
                phone = contacts?.phone.orEmpty(),
                telegram = contacts?.telegram.orEmpty(),
                facebook = contacts?.facebook.orEmpty(),
                context = context
            )

            Spacer(Modifier.height(10.dp))
            Footer(source = source, loading = loading, onRefresh = { vm.refresh() })
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun Header() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(8.dp))
        Image(
            painter = painterResource(R.drawable.ic_logo_mark),
            contentDescription = "شعار اتصالات المرشد",
            modifier = Modifier.size(width = 64.dp, height = 56.dp)
        )
        Spacer(Modifier.height(6.dp))
        // اسم المحل هو أكبر نص بالشاشة
        Text(
            "اتصالات المرشد",
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextMain
        )
        Text("Al-Murshid Telecom", fontSize = 13.sp, color = Teal, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "صيانة • سوفتوير • برمجة • إكسسوارات • شام كاش",
            fontSize = 11.sp,
            color = TextDim,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ConnectButton(state: ConnState, onClick: () -> Unit) {
    val color by animateColorAsState(
        targetValue = when (state) {
            ConnState.Connected -> Green
            ConnState.Connecting, ConnState.Disconnecting -> Amber
            ConnState.Error -> Red
            ConnState.Disconnected -> Gray
        },
        label = "buttonColor"
    )
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
        label = "pulseValue"
    )
    val busy = state == ConnState.Connecting || state == ConnState.Disconnecting
    val active = state == ConnState.Connected

    Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxR = size.minDimension / 2f
            val baseR = maxR * 0.66f
            drawCircle(color.copy(alpha = 0.10f), radius = maxR * 0.92f)
            if (busy) {
                drawCircle(
                    color.copy(alpha = (1f - pulse) * 0.5f),
                    radius = baseR + (maxR - baseR) * pulse,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
            if (active) {
                drawCircle(
                    color.copy(alpha = 0.30f),
                    radius = maxR * 0.80f,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(Surface2)
                .border(4.dp, color, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            PowerIcon(color)
        }
    }
}

@Composable
private fun PowerIcon(color: Color) {
    Canvas(Modifier.size(56.dp)) {
        val w = 6.dp.toPx()
        val diameter = size.width - 2 * w
        val top = (size.height - diameter) / 2f + 3.dp.toPx()
        drawArc(
            color = color,
            startAngle = -50f,
            sweepAngle = 280f,
            useCenter = false,
            topLeft = Offset(w, top),
            size = Size(diameter, diameter),
            style = Stroke(width = w, cap = StrokeCap.Round)
        )
        drawLine(
            color = color,
            start = Offset(size.width / 2f, w / 2f),
            end = Offset(size.width / 2f, size.height / 2f),
            strokeWidth = w,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun StatusText(state: ConnState, seconds: Long, error: String?) {
    val label = when (state) {
        ConnState.Disconnected -> "غير متصل"
        ConnState.Connecting -> "جاري الاتصال..."
        ConnState.Connected -> "متصل"
        ConnState.Disconnecting -> "جاري القطع..."
        ConnState.Error -> "فشل الاتصال"
    }
    val color = when (state) {
        ConnState.Connected -> Green
        ConnState.Connecting, ConnState.Disconnecting -> Amber
        ConnState.Error -> Red
        ConnState.Disconnected -> TextDim
    }
    Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color)
    val sub = when (state) {
        ConnState.Connected -> formatDuration(seconds)
        ConnState.Error -> error.orEmpty()
        ConnState.Disconnected -> "اضغط الزر للاتصال"
        else -> ""
    }
    if (sub.isNotEmpty()) {
        Text(
            sub,
            fontSize = 14.sp,
            color = TextDim,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun ServerPicker(
    servers: List<VpnServer>,
    selected: VpnServer?,
    enabled: Boolean,
    onSelect: (VpnServer) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Surface1),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = enabled && servers.isNotEmpty()) { open = true }
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("السيرفر", fontSize = 12.sp, color = TextDim)
                    Text(
                        selected?.name ?: "لا توجد سيرفرات",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextMain
                    )
                }
                Text("▾", color = TextDim, fontSize = 18.sp)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            servers.forEach { server ->
                DropdownMenuItem(
                    text = { Text(server.name) },
                    onClick = {
                        onSelect(server)
                        open = false
                    }
                )
            }
        }
    }
}

@Composable
private fun StatsCard(
    serverName: String?,
    connected: Boolean,
    rxSpeed: Long,
    txSpeed: Long,
    rxBytes: Long,
    txBytes: Long
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Surface1),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("بيانات الاتصال", fontSize = 13.sp, color = TextDim)
            Row(Modifier.fillMaxWidth()) {
                StatItem("↓ سرعة التنزيل", if (connected) formatSpeed(rxSpeed) else "—", Modifier.weight(1f))
                StatItem("↑ سرعة الرفع", if (connected) formatSpeed(txSpeed) else "—", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                StatItem("إجمالي التنزيل", if (connected) formatBytes(rxBytes) else "—", Modifier.weight(1f))
                StatItem("إجمالي الرفع", if (connected) formatBytes(txBytes) else "—", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                StatItem("السيرفر", serverName ?: "—", Modifier.weight(1f))
                StatItem("البروتوكول", "WireGuard", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, fontSize = 12.sp, color = TextDim)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = TextMain, maxLines = 1)
    }
}

@Composable
private fun ContactRow(
    whatsapp: String,
    phone: String,
    telegram: String,
    facebook: String,
    context: Context
) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("الدعم الفني", fontSize = 13.sp, color = TextDim)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val waNumber = whatsapp.filter { it.isDigit() }
            if (waNumber.isNotEmpty()) {
                ContactButton("واتساب", Color(0xFF25D366), Modifier.weight(1f)) {
                    val msg = Uri.encode("مرحباً، أحتاج مساعدة بخصوص تطبيق اتصالات المرشد")
                    openUri(context, "https://wa.me/$waNumber?text=$msg")
                }
            }
            if (phone.isNotEmpty()) {
                ContactButton("اتصال", Teal, Modifier.weight(1f)) {
                    openUri(context, "tel:${phone.filter { it.isDigit() || it == '+' }}", Intent.ACTION_DIAL)
                }
            }
            if (telegram.isNotEmpty()) {
                ContactButton("تيليجرام", Color(0xFF3AA6E0), Modifier.weight(1f)) {
                    val url = if (telegram.startsWith("http")) telegram else "https://t.me/${telegram.removePrefix("@")}"
                    openUri(context, url)
                }
            }
            if (facebook.isNotEmpty()) {
                ContactButton("فيسبوك", Color(0xFF4C7BF4), Modifier.weight(1f)) {
                    val url = if (facebook.startsWith("http")) facebook else "https://facebook.com/$facebook"
                    openUri(context, url)
                }
            }
        }
    }
}

@Composable
private fun ContactButton(text: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(46.dp),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Bg)
    ) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun Footer(source: ConfigSource?, loading: Boolean, onRefresh: () -> Unit) {
    val sourceText = when (source) {
        ConfigSource.Remote -> "السيرفرات محدّثة من الإنترنت"
        ConfigSource.Cache -> "سيرفرات محفوظة (لا يوجد اتصال بالرابط)"
        ConfigSource.Bundled -> "سيرفرات افتراضية مدمجة"
        null -> "جاري التحميل..."
    }
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(sourceText, fontSize = 11.sp, color = TextDim)
            Text("الإصدار ${BuildConfig.VERSION_NAME}", fontSize = 11.sp, color = TextDim)
        }
        if (loading) {
            CircularProgressIndicator(Modifier.size(20.dp), color = Teal, strokeWidth = 2.dp)
            Spacer(Modifier.width(8.dp))
        }
        TextButton(onClick = onRefresh, enabled = !loading) {
            Text("تحديث السيرفرات", color = Teal, fontSize = 13.sp)
        }
    }
}

private fun openUri(context: Context, uri: String, action: String = Intent.ACTION_VIEW) {
    try {
        context.startActivity(Intent(action, Uri.parse(uri)))
    } catch (_: Exception) {
        // ما في تطبيق يفتح الرابط
    }
}

private fun formatBytes(b: Long): String = when {
    b < 1024L -> "$b B"
    b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024))
    else -> String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024))
}

private fun formatSpeed(bytesPerSec: Long): String = formatBytes(bytesPerSec) + "/s"

private fun formatDuration(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}
