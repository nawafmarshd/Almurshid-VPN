package com.almurshid.telecom.vpn

import com.almurshid.telecom.data.VpnServer
import com.wireguard.config.Config
import java.io.ByteArrayInputStream

/** يحوّل بيانات السيرفر لإعداد WireGuard جاهز للتشغيل. */
object WgConfigFactory {

    fun build(server: VpnServer): Config {
        val raw = server.wgConfig
        val text = if (!raw.isNullOrBlank()) raw else toWgQuick(server)
        return Config.parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
    }

    private fun toWgQuick(s: VpnServer): String = buildString {
        appendLine("[Interface]")
        appendLine("PrivateKey = ${s.privateKey}")
        appendLine("Address = ${s.address}")
        if (s.dns.isNotBlank()) appendLine("DNS = ${s.dns}")
        s.mtu?.let { appendLine("MTU = $it") }
        appendLine()
        appendLine("[Peer]")
        appendLine("PublicKey = ${s.publicKey}")
        if (s.presharedKey.isNotBlank()) appendLine("PresharedKey = ${s.presharedKey}")
        appendLine("AllowedIPs = ${s.allowedIps}")
        appendLine("Endpoint = ${s.endpoint}")
        if (s.keepalive > 0) appendLine("PersistentKeepalive = ${s.keepalive}")
    }
}
