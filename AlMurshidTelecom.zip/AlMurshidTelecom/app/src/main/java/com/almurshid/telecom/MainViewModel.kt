package com.almurshid.telecom

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.almurshid.telecom.data.AppConfig
import com.almurshid.telecom.data.ConfigSource
import com.almurshid.telecom.data.RemoteConfigRepository
import com.almurshid.telecom.data.VpnServer
import com.almurshid.telecom.vpn.VpnManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = RemoteConfigRepository(app)
    private val prefs = app.getSharedPreferences("ui", Context.MODE_PRIVATE)

    private val _config = MutableStateFlow<AppConfig?>(null)
    val config: StateFlow<AppConfig?> = _config.asStateFlow()

    private val _source = MutableStateFlow<ConfigSource?>(null)
    val source: StateFlow<ConfigSource?> = _source.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _selectedId = MutableStateFlow(prefs.getString("server", null))

    val selectedServer: StateFlow<VpnServer?> =
        combine(_config, _selectedId) { cfg, id ->
            cfg?.servers?.firstOrNull { it.id == id } ?: cfg?.servers?.firstOrNull()
        }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val vpn = VpnManager.status

    init {
        refresh()
    }

    /** تحديث قائمة السيرفرات من الرابط الخارجي. */
    fun refresh() {
        if (_loading.value) return
        viewModelScope.launch {
            _loading.value = true
            try {
                val result = repo.load()
                _config.value = result.config
                _source.value = result.source
            } finally {
                _loading.value = false
            }
        }
    }

    fun select(server: VpnServer) {
        _selectedId.value = server.id
        prefs.edit().putString("server", server.id).apply()
    }

    fun connect() {
        selectedServer.value?.let { VpnManager.connect(it) }
    }

    fun disconnect() = VpnManager.disconnect()
}
