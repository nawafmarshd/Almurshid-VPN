package com.almurshid.telecom.data

/** سيرفر واحد. إمّا wgConfig (نص wg-quick كامل) أو الحقول المفصّلة. */
data class VpnServer(
    val id: String,
    val name: String,
    val wgConfig: String? = null,
    val privateKey: String = "",
    val address: String = "",
    val dns: String = "1.1.1.1",
    val mtu: Int? = null,
    val publicKey: String = "",
    val presharedKey: String = "",
    val endpoint: String = "",
    val allowedIps: String = "0.0.0.0/0, ::/0",
    val keepalive: Int = 25
)

data class Contacts(
    val whatsapp: String = "",
    val phone: String = "",
    val telegram: String = "",
    val facebook: String = ""
)

data class AppConfig(
    val version: Int,
    val announcement: String,
    val contacts: Contacts,
    val servers: List<VpnServer>
)

enum class ConfigSource { Remote, Cache, Bundled }

data class LoadedConfig(val config: AppConfig, val source: ConfigSource)
