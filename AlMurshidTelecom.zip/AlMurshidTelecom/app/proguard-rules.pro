# مكتبة WireGuard تستخدم JNI وانعكاس (reflection) فلازم نحافظ عليها
-keep class com.wireguard.** { *; }
-dontwarn com.wireguard.**
